#include "edf/edf_file.h"

namespace eeg_modelling {

EdfFile::EdfFile() {}

EdfFile::~EdfFile() {}

}  // namespace eeg_modelling
