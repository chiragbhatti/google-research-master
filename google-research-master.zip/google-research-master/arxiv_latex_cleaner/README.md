This code has moved to
[a new repository](https://github.com/google-research/arxiv-latex-cleaner).
