This folder exemplifies the data format the the training code expects. The
images are from the [Cityscapes](https://www.cityscapes-dataset.com/) dataset.
The [Struct2depth repository]
(https://github.com/tensorflow/models/tree/master/research/struct2depth)
provides scripts for generating data in this format.
