# Extrapolation Detection
This repository contains the code behind "Detecting Extrapolation with Influence
Functions" by David Madras, James Atwood, and Alex D'Amour (to appear in the
2019 ICML Workshop on Uncertainty & Robustness in Deep Learning).
