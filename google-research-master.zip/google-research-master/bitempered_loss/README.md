# Robust Bi-Tempered Logistic Loss Based on Bregman Divergences.

Source: https://arxiv.org/pdf/1906.03361.pdf
